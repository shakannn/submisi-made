package com.darkshan.mymovcat4.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.activity.DetailActivity
import com.darkshan.mymovcat4.activity.MainActivity
import com.darkshan.mymovcat4.adapter.TvSeriesAdapter
import com.darkshan.mymovcat4.api.TvSeriesService
import com.darkshan.mymovcat4.api.TvSeriesView
import com.darkshan.mymovcat4.api.invisible
import com.darkshan.mymovcat4.api.visible
import com.darkshan.mymovcat4.model.TvSeries
import com.darkshan.mymovcat4.model.TvSeriesAdapterModel
import com.darkshan.mymovcat4.viewmodel.TvSeriesViewModel


class TvSeriesFragment : Fragment(), TvSeriesView {

    private lateinit var service: TvSeriesService
    private lateinit var rv_tv: RecyclerView
    lateinit var progressBar: ProgressBar
    private lateinit var tvSeriesAdapter: TvSeriesAdapter
    private val dataTvSeries = mutableListOf<TvSeriesAdapterModel>()

    companion object {
        const val INSTANCE = "instance"
        fun newInstance() = TvSeriesFragment()
    }

    private lateinit var viewModel: TvSeriesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.tv_series_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rv_tv = view.findViewById(R.id.rv_tv_list)
        progressBar = view.findViewById(R.id.progbar)
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        viewModel = ViewModelProvider(
            requireActivity(),
            ViewModelProvider.NewInstanceFactory()
        )[TvSeriesViewModel::class.java]
        if (viewModel.getTvSeries().value != null) {
            progressBar.invisible()
        }
        viewModel.getTvSeries().observe(requireActivity(), getTvSeries)
        tvSeriesAdapter = TvSeriesAdapter(requireContext(), dataTvSeries) {
            val i = Intent(requireContext(), DetailActivity::class.java)
            i.putExtra(MainActivity.DATA_EXTRA_TV, it)
            i.putExtra(MainActivity.TYPE, MainActivity.TV_SERIES)
            startActivity(i)
        }

        rv_tv.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = tvSeriesAdapter
        }
        super.onActivityCreated(savedInstanceState)

    }


    private val getTvSeries = Observer<TvSeries> {
        if (it != null) {
            tvSeriesAdapter.setData(it.results)
        }
        hideTvLoading()
    }

    override fun showTvLoading() {
        progressBar.visible()
    }

    override fun hideTvLoading() {
        progressBar.invisible()
    }


    override fun loadListTvSeries(data: TvSeries) {
        viewModel.setTvSeries(data)

    }

}
