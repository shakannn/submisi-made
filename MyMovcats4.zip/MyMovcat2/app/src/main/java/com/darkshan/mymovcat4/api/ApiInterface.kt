package com.darkshan.mymovcat4.api

import com.darkshan.mymovcat4.model.Movie
import com.darkshan.mymovcat4.model.Movies
import com.darkshan.mymovcat4.model.TvSerie
import com.darkshan.mymovcat4.model.TvSeries
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiInterface {

    @GET("discover/movie")
    fun getMovie(
        @Query("api_key") api_key: String,
        @Query("language") language: String = "en-US"
    ): Call<Movies>

    @GET("discover/tv")
    fun getTv(
        @Query("api_key") api_key: String,
        @Query("language") language: String = "en-US"
    ): Call<TvSeries>

    @GET("movie/{id}")
    fun getDetailMovie(
        @Path("id") id: String,
        @Query("api_key") api_key: String,
        @Query("language") language: String = "en-US"
    ): Call<Movie>

    @GET("tv/{id}")
    fun getDetailTv(
        @Path("id") id: String,
        @Query("api_key") api_key: String,
        @Query("language") language: String = "en-US"
    ): Call<TvSerie>

}