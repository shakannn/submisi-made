package com.darkshan.mymovcat4.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.darkshan.mymovcat4.activity.MainActivity
import com.darkshan.mymovcat4.model.FavoriteMovie
import com.darkshan.mymovcat4.model.FavoritesTvSeries

@Database(
    entities = arrayOf(FavoriteMovie::class, FavoritesTvSeries::class),
    version = 1,
    exportSchema = false
)
abstract class FavoriteDB : RoomDatabase() {

    abstract fun getFavoriteDao(): FavoriteDao

    companion object {
        // Singleton prevents multiple instances of database opening at the
        // same time.
        @Volatile
        private var INSTANCE: FavoriteDB? = null

        fun getDatabase(context: Context): FavoriteDB {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FavoriteDB::class.java,
                    MainActivity.DBNAME
                ).allowMainThreadQueries().build()
                INSTANCE = instance
                return instance
            }
        }
    }
}