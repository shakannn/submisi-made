package com.darkshan.mymovcat4.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.darkshan.mymovcat4.model.Movie
import com.darkshan.mymovcat4.model.TvSerie

class DetailViewModel : ViewModel() {
    private val detailMovie = MutableLiveData<Movie>()
    private val detailTv = MutableLiveData<TvSerie>()

    fun setDetailMovie(data: Movie) {
        detailMovie.postValue(data)
    }

    fun setDetailTv(data: TvSerie) {
        detailTv.postValue(data)
    }

    fun getDetailMovie(): LiveData<Movie> {
        return detailMovie
    }

    fun getDetailTv(): LiveData<TvSerie> {
        return detailTv
    }

}