package com.darkshan.mymovcat4.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Movie(
    val title: String,
    val status: String,
    val release_date: String,
    val genres: List<Genre>,
    val popularity: String,
    val vote_average: String,
    val poster_path: String,
    val overview: String
) : Parcelable

@Parcelize
data class TvSerie(
    val name: String,
    val status: String,
    val first_air_date: String,
    val genres: List<Genre>,
    val popularity: String,
    val vote_average: String,
    val poster_path: String,
    val overview: String
) : Parcelable

@Parcelize
data class Genre(val name: String) : Parcelable
