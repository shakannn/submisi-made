package com.darkshan.mymovcat4.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.activity.DetailActivity
import com.darkshan.mymovcat4.activity.MainActivity
import com.darkshan.mymovcat4.adapter.FavoritesMovieAdapter
import com.darkshan.mymovcat4.model.MovieAdapterModel
import com.darkshan.mymovcat4.viewmodel.FavoriteMovieViewModel

/**
 * A simple [Fragment] subclass.
 */
class FavoriteMovieFragment : Fragment() {
    private lateinit var rvlist2: RecyclerView
    private lateinit var progb2: ProgressBar

    private lateinit var fmovieViewMode: FavoriteMovieViewModel
    private lateinit var fMovieAdapter: FavoritesMovieAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favorite_movie, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        progb2 = view.findViewById(R.id.progb2)
        rvlist2 = view.findViewById(R.id.rv_list2)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        fmovieViewMode = ViewModelProvider(
            requireActivity()
        )[FavoriteMovieViewModel::class.java]

        fMovieAdapter = FavoritesMovieAdapter(requireContext()) {
            //val data=MovieAdapterModel(it.id,it.title,it.vote_average,it.poster_path)
            val i = Intent(requireContext(), DetailActivity::class.java)
            val data = MovieAdapterModel(it.id, it.title, it.vote_average, it.poster_path)
            i.putExtra(MainActivity.DATA_EXTRA_MOVIE, data)
            i.putExtra(MainActivity.TYPE, MainActivity.MOVIE)
            startActivity(i)
        }
        initListenResult()
        rvlist2.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = fMovieAdapter
        }
        progb2.visibility = View.INVISIBLE
    }

    private fun initListenResult() {
        fmovieViewMode.listenResult().observe(requireActivity(), Observer {
            it?.let {
                fMovieAdapter.setData(it)
            }
        })
    }
}
