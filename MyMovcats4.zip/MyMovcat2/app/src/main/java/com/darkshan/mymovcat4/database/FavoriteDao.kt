package com.darkshan.mymovcat4.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.darkshan.mymovcat4.activity.MainActivity
import com.darkshan.mymovcat4.model.FavoriteMovie
import com.darkshan.mymovcat4.model.FavoritesTvSeries

@Dao
interface FavoriteDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertMovie(FMovie: FavoriteMovie)

    @Query("DELETE FROM ${MainActivity.TBL_Tv_NAME} WHERE id=:id")
    fun deleteFavTvSeries(id: String)

    @Delete
    fun deleteFavTv(data:FavoritesTvSeries)

    @Query("DELETE FROM ${MainActivity.TBL_Movie_NAME} WHERE id=:id")
    fun deleteFavMovie(id: String)
    @Query("DELETE FROM ${MainActivity.TBL_Tv_NAME} WHERE name=:name")
    fun  deleteTvByName(name:String)
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertTvSeries(FTvSeries: FavoritesTvSeries)

    @Query("SELECT * FROM ${MainActivity.TBL_Movie_NAME} WHERE id=:id")
    fun getDetMovie(id: String): List<FavoriteMovie>

    @Query("SELECT * FROM ${MainActivity.TBL_Tv_NAME} WHERE id=:id")
    fun getDetTvSeries(id: String): List<FavoritesTvSeries>

    @Query("SELECT * FROM ${MainActivity.TBL_Movie_NAME}")
    fun getAllMovies(): LiveData<List<FavoriteMovie>>

    @Query("SELECT * FROM ${MainActivity.TBL_Tv_NAME}")
    fun getAllTvSeries(): LiveData<List<FavoritesTvSeries>>

}