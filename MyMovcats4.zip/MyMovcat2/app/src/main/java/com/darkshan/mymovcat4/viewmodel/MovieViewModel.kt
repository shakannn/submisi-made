package com.darkshan.mymovcat4.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.darkshan.mymovcat4.model.Movies


class MovieViewModel : ViewModel() {
    private val listMovies = MutableLiveData<Movies>()
    fun setMovies(data: Movies) {

        listMovies.postValue(data)
    }

    fun getMovies(): LiveData<Movies> {
        return listMovies
    }
}
