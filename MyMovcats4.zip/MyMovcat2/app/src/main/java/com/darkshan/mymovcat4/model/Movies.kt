package com.darkshan.mymovcat4.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MovieAdapterModel(
    val id: String,
    val title: String,
    val vote_average: String,
    val poster_path: String
) : Parcelable

@Parcelize
data class TvSeriesAdapterModel(
    val id: String,
    val name: String,
    val vote_average: String,
    val poster_path: String
) : Parcelable

@Parcelize
data class Movies(val results: List<MovieAdapterModel>) : Parcelable

@Parcelize
data class TvSeries(val results: List<TvSeriesAdapterModel>) : Parcelable