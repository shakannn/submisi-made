package com.darkshan.mymovcat4.activity

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.api.*
import com.darkshan.mymovcat4.model.*
import com.darkshan.mymovcat4.viewmodel.DetailViewModel
import com.darkshan.mymovcat4.viewmodel.FavoriteMovieViewModel
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity(), DetailView {
    private lateinit var detailViewModel: DetailViewModel
    private lateinit var detailService: DetailServices
    private lateinit var favoriteMovieViewModel: FavoriteMovieViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setTitle("Detail")

        favoriteMovieViewModel = ViewModelProvider(this)[FavoriteMovieViewModel::class.java]

        val apiService = ApiClient.getRetrofitInst()
        detailService = DetailServices(this, apiService)
        detailViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[DetailViewModel::class.java]

        val type = intent.getStringExtra(MainActivity.TYPE)

        if (detailViewModel.getDetailMovie().value != null) {
            detailViewModel.getDetailMovie().observe(this, getMovie)
        } else if (detailViewModel.getDetailTv().value != null) {
            detailViewModel.getDetailTv().observe(this, getTv)
        } else {
            when (type) {
                MainActivity.MOVIE -> whenDataIsMovie()
                MainActivity.TV_SERIES -> whenDataIsTv()
            }

        }
    }

    fun getMovieParcel(): MovieAdapterModel {
        return intent.getParcelableExtra<MovieAdapterModel>(MainActivity.DATA_EXTRA_MOVIE)
    }

    fun getTvParcel(): TvSeriesAdapterModel {
        return intent.getParcelableExtra<TvSeriesAdapterModel>(MainActivity.DATA_EXTRA_TV)
    }

    private fun setFavorite(idMovie: String? = null, idTv: String? = null) {
        if (idTv != null) {
            if (getTvFromDb(idTv).isEmpty()) {
                actionFav.setImageDrawable(resources.getDrawable(R.drawable.ic_favorite_border_black_24dp))

            } else if (getTvFromDb(idTv).isNotEmpty()) {
                actionFav.setImageDrawable(resources.getDrawable(R.drawable.ic_favorite_black_24dp))
            }
        }
        if (idMovie != null) {
            if (getMovieFromDb(idMovie).isEmpty()) {
                actionFav.setImageDrawable(resources.getDrawable(R.drawable.ic_favorite_border_black_24dp))
            } else if (getMovieFromDb(idMovie).isNotEmpty()) {
                actionFav.setImageDrawable(resources.getDrawable(R.drawable.ic_favorite_border_black_24dp))
            }

        }
    }

    fun getMovieFromDb(idMovie: String): List<FavoriteMovie> {
        return favoriteMovieViewModel.getMovieById(idMovie)
    }

    fun getTvFromDb(idTv: String): List<FavoritesTvSeries> {
        return favoriteMovieViewModel.getTvSeriesById(idTv)
    }

    private val getMovie = Observer<Movie> {
        if (it != null) {
            val index = it.genres.size - 1
            val imageurl = ApiClient.IMAGE_BASE_URL + it.poster_path

            txt_name.text = it.title
            status.text = it.status
            genrename.text = it.genres[index].name
            popularityVal.text = it.popularity
            txtrate.text = it.vote_average
            txt_desc.text = it.overview
            realeasedate.text = it.release_date

            Glide.with(this).load(imageurl).centerCrop()
                .apply(RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL)).into(imagePoster2)
        }
        hideLoading()
    }

    fun whenDataIsMovie() {
        val idMovie = getMovieParcel().id
        setFavorite(idMovie = idMovie)
        detailService.loadDetailMovies(idMovie)
        actionFav.setOnClickListener {
            actionFavButton(movie = getMovieParcel())
        }
        val listMovieDb = favoriteMovieViewModel.getMovieById(idMovie)
        detailViewModel.getDetailMovie().observe(this, getMovie)
    }

    fun whenDataIsTv() {
        val idTv = getTvParcel().id
        setFavorite(idTv = idTv)
        actionFav.setOnClickListener { actionFavButton(tv = getTvParcel()) }
        val listTvieDb = favoriteMovieViewModel.getTvSeriesById(idTv)
        detailService.loadDetailTvSeries(idTv)
        detailViewModel.getDetailTv().observe(this, getTv)
    }

    private val getTv = Observer<TvSerie> {
        if (it != null) {
            val index = it.genres.size - 1
            val imageUrl = ApiClient.IMAGE_BASE_URL + it.poster_path

            txt_name.text = it.name
            status.text = it.status
            genrename.text = it.genres[index].name
            popularityVal.text = it.popularity
            txtrate.text = it.vote_average
            txt_desc.text = it.overview
            realeasedate.text = it.first_air_date

            Glide.with(this).load(imageUrl).centerCrop()
                .apply(RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL)).into(imagePoster2)


        }
        hideLoading()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.det_menu, menu)
        return super.onCreateOptionsMenu(menu)


    }

    override fun showLoading() {
        pbar.visible()
    }

    override fun hideLoading() {
        pbar.invisible()
    }

    override fun loadDetailMovie(data: Movie) {
        detailViewModel.setDetailMovie(data)
    }

    override fun loadDetailTvSeries(data: TvSerie) {
        detailViewModel.setDetailTv(data)
    }

    private fun actionFavButton(
        movie: MovieAdapterModel? = null,
        tv: TvSeriesAdapterModel? = null
    ) {
        if (tv != null) {
            if (getTvFromDb(tv.id).isEmpty()) {
                val data = FavoritesTvSeries(
                    id = tv.id,
                    name = tv.name,
                    vote_average = tv.vote_average,
                    poster_path = tv.poster_path
                )
                favoriteMovieViewModel.savemovieTv(data)
                setFavorite(idTv = tv.id)
                Toast.makeText(applicationContext,resources.getString(R.string.added),Toast.LENGTH_LONG).show()
            } else if (getTvFromDb(tv.id).isNotEmpty()) {
                val data = FavoritesTvSeries(
                    id = tv.id,
                    name = tv.name,
                    vote_average = tv.vote_average,
                    poster_path = tv.poster_path
                )
                favoriteMovieViewModel.deleteTvByData(data)
                setFavorite(idTv = tv.id)
                Toast.makeText(applicationContext,resources.getString(R.string.deleted),Toast.LENGTH_LONG).show()
            }
        }
        if (movie != null) {
            if (getMovieFromDb(movie.id).isEmpty()) {
                val data = FavoriteMovie(
                    id = movie.id,
                    title = movie.title,
                    vote_average = movie.vote_average,
                    poster_path = movie.poster_path
                )
                favoriteMovieViewModel.savemovie(data)
                setFavorite(idMovie = movie.id)
                Toast.makeText(applicationContext,resources.getString(R.string.added),Toast.LENGTH_LONG).show()
            } else if (getMovieFromDb(movie.id).isNotEmpty()) {
                favoriteMovieViewModel.deletMovie(movie.id)
                setFavorite(idMovie = movie.id)
                Toast.makeText(applicationContext,resources.getString(R.string.deleted),Toast.LENGTH_LONG).show()
            }

        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}

