package com.darkshan.mymovcat4.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.darkshan.mymovcat4.model.TvSeries

class TvSeriesViewModel : ViewModel() {
    val listTv = MutableLiveData<TvSeries>()
    fun setTvSeries(data: TvSeries) {
        listTv.postValue(data)
    }

    fun getTvSeries(): LiveData<TvSeries> {
        return listTv
    }
}
