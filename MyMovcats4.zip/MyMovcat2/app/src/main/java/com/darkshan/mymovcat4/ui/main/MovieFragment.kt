package com.darkshan.mymovcat4.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.activity.DetailActivity
import com.darkshan.mymovcat4.activity.MainActivity
import com.darkshan.mymovcat4.adapter.MovieAdapter
import com.darkshan.mymovcat4.api.MovieView
import com.darkshan.mymovcat4.api.invisible
import com.darkshan.mymovcat4.api.visible
import com.darkshan.mymovcat4.model.MovieAdapterModel
import com.darkshan.mymovcat4.model.Movies
import com.darkshan.mymovcat4.viewmodel.MovieViewModel


class MovieFragment : Fragment(), MovieView {
    private lateinit var rv_mov: RecyclerView
    private lateinit var progressbar: ProgressBar
    private lateinit var movieAdapter: MovieAdapter

    //private lateinit var moviesService: MoviesService
    private val dataMovie = mutableListOf<MovieAdapterModel>()

    private lateinit var viewModel: MovieViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.movie_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rv_mov = view.findViewById(R.id.rv_list)
        progressbar = view.findViewById(R.id.progb)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        viewModel = ViewModelProvider(
            requireActivity(),
            ViewModelProvider.NewInstanceFactory()
        )[MovieViewModel::class.java]
        viewModel.getMovies().observe(requireActivity(), getMovies)
        if (viewModel.getMovies().value != null) {
            progressbar.invisible()
        }

        movieAdapter = MovieAdapter(requireContext(), dataMovie) {
            val i = Intent(requireContext(), DetailActivity::class.java)
            i.putExtra(MainActivity.DATA_EXTRA_MOVIE, it)
            i.putExtra(MainActivity.TYPE, MainActivity.MOVIE)
            startActivity(i)
        }
        rv_mov.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = movieAdapter
        }

        super.onActivityCreated(savedInstanceState)

    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("instance", "saved")
        super.onSaveInstanceState(outState)
    }

    private val getMovies = Observer<Movies> {
        if (it != null) {
            movieAdapter.setData(it.results)
        }
        hideLoading()
    }

    override fun showLoading() {
        progressbar.visible()
    }

    override fun hideLoading() {
        progressbar.invisible()
    }

    override fun loadListMovie(data: Movies) {

    }


}