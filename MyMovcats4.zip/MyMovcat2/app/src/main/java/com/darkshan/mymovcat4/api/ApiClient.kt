package com.darkshan.mymovcat4.api

import com.darkshan.mymovcat4.BuildConfig
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class ApiClient {

    companion object {
        lateinit var retrofit: Retrofit
        const val BASE_URL = "https://api.themoviedb.org/3/"
        const val IMAGE_BASE_URL = "https://image.tmdb.org/t/p/original"
        const val API_KEY = BuildConfig.TMDB_API_KEY
        fun getRetrofitInst(): ApiInterface {
            retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()

            return retrofit.create(ApiInterface::class.java)
        }
    }

}