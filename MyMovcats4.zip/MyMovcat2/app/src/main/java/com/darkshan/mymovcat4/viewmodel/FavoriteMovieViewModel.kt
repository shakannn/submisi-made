package com.darkshan.mymovcat4.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.darkshan.mymovcat4.database.FavoriteDB
import com.darkshan.mymovcat4.database.FavoriteRepository
import com.darkshan.mymovcat4.model.FavoriteMovie
import com.darkshan.mymovcat4.model.FavoritesTvSeries

class FavoriteMovieViewModel(application: Application) : AndroidViewModel(application) {
    lateinit var listMovie: LiveData<List<FavoriteMovie>>
    lateinit var listTv: LiveData<List<FavoritesTvSeries>>
    private val favoriteRepository: FavoriteRepository

    init {
        val dao = FavoriteDB.getDatabase(application).getFavoriteDao()
        favoriteRepository = FavoriteRepository(dao)
        subscribeDataMovie()
        subscribeDataTv()

    }

    fun savemovieTv(favoritesTvSeries: FavoritesTvSeries) {
        favoriteRepository.saveTvSerie(favoritesTvSeries)
    }

    fun deletMovieTv(id: String) {
        favoriteRepository.deleteFavTV(id)
    }
    fun deletTvByName(name: String) {
        favoriteRepository.tvDeleteByName(name)
    }
    fun deleteTvByData(data:FavoritesTvSeries){
        favoriteRepository.deleteTvByData(data)
    }

    fun getMovieById(id: String): List<FavoriteMovie> {
        return favoriteRepository.loadMovieById(id)
    }

    fun getTvSeriesById(id: String): List<FavoritesTvSeries> {
        return favoriteRepository.loadTvSerieById(id)
    }

    fun listenResultTv(): LiveData<List<FavoritesTvSeries>> {
        return listTv

    }

    private fun subscribeDataTv() {
        listTv = favoriteRepository.loadFavTvSerieLiveData()
    }

    fun savemovie(favoriteMovie: FavoriteMovie) {
        favoriteRepository.saveMovie(favoriteMovie)
    }

    fun deletMovie(id: String) {
        favoriteRepository.deleteFavmovie(id)
    }

    fun listenResult(): LiveData<List<FavoriteMovie>> {
        return listMovie

    }

    private fun subscribeDataMovie() {
        listMovie = favoriteRepository.loadFavMovieLiveData()
    }
}