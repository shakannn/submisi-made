package com.darkshan.mymovcat4.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.api.ApiClient
import com.darkshan.mymovcat4.model.MovieAdapterModel
import com.darkshan.mymovcat4.model.TvSeriesAdapterModel
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_list.*

val requestOptions = RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL)

class MovieAdapter(
    private val context: Context,
    private val listmovie: MutableList<MovieAdapterModel>,
    private val onClickListener: (MovieAdapterModel) -> Unit
) :
    RecyclerView.Adapter<MovieAdapter.ViewHolder>() {

    inner class ViewHolder(override val containerView: View) :
        RecyclerView.ViewHolder(containerView), LayoutContainer {

        fun bind(
            movie: MovieAdapterModel,
            context: Context,
            onClickListener: (MovieAdapterModel) -> Unit
        ) {

            Glide.with(context)
                .load(ApiClient.IMAGE_BASE_URL + movie.poster_path)
                .apply(requestOptions)
                .into(imgmov_poster)
            txtmov_name.text = movie.title
            txtmov_rate.text = movie.vote_average

            containerView.setOnClickListener { onClickListener(movie) }
        }
    }


    override fun getItemCount(): Int {
        return listmovie.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_list, parent, false))

    fun setData(movies: List<MovieAdapterModel>) {
        listmovie.clear()
        listmovie.addAll(movies)
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listmovie[position], context, onClickListener)
    }

}

class TvSeriesAdapter(
    private val context: Context,
    private val listTv: MutableList<TvSeriesAdapterModel>,
    private val onClickListener: (TvSeriesAdapterModel) -> Unit
) :
    RecyclerView.Adapter<TvSeriesAdapter.ViewHolder>() {

    inner class ViewHolder(override val containerView: View) :
        RecyclerView.ViewHolder(containerView), LayoutContainer {

        fun bind(
            tvSerie: TvSeriesAdapterModel,
            context: Context,
            onClickListener: (TvSeriesAdapterModel) -> Unit
        ) {
            Glide.with(context)
                .load(ApiClient.IMAGE_BASE_URL + tvSerie.poster_path)
                .apply(requestOptions)
                .into(imgmov_poster)
            txtmov_name.text = tvSerie.name
            txtmov_rate.text = tvSerie.vote_average

            containerView.setOnClickListener { onClickListener(tvSerie) }
        }
    }


    override fun getItemCount(): Int {
        return listTv.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_list, parent, false))

    fun setData(data: List<TvSeriesAdapterModel>) {
        listTv.clear()
        listTv.addAll(data)
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listTv[position], context, onClickListener)
    }

}


