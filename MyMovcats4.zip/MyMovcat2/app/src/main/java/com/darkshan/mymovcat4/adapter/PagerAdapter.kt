package com.darkshan.mymovcat4.adapter

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class PagerAdapter(private val context: Context, fm: FragmentManager) : FragmentPagerAdapter(fm) {
    private val listFragment = ArrayList<Fragment>()
    private val listTabTitle = ArrayList<String>()
    override fun getItem(position: Int): Fragment {
        return listFragment[position]
    }

    override fun getCount(): Int {
        return listFragment.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return listTabTitle[position]
    }

    fun addTabs(fragment: Fragment, title: String) {
        listFragment.add(fragment)
        listTabTitle.add(title)
    }
}