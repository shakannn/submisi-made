package com.darkshan.mymovcat4.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.api.ApiClient
import com.darkshan.mymovcat4.model.FavoriteMovie
import com.darkshan.mymovcat4.model.FavoritesTvSeries
import kotlinx.android.synthetic.main.item_list.view.*

class FavoritesMovieAdapter(
    private val context: Context,
    private val onClickListener: (FavoriteMovie) -> Unit
) : RecyclerView.Adapter<FavoritesMovieAdapter.ViewHolder>() {
    private var listFav = listOf<FavoriteMovie>()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun Bind(
            movie: FavoriteMovie,
            context: Context,
            onClickListener: (FavoriteMovie) -> Unit
        ) {
            with(itemView) {
                Glide.with(context)
                    .load(ApiClient.IMAGE_BASE_URL + movie.poster_path)
                    .apply(requestOptions)
                    .into(imgmov_poster)
                txtmov_name.text = movie.title
                txtmov_rate.text = movie.vote_average
                itemView.setOnClickListener { onClickListener(movie) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_list, parent, false))


    override fun getItemCount(): Int = listFav.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.Bind(listFav[position], context, onClickListener)
    }

    fun setData(data: List<FavoriteMovie>) {
        listFav = data
        notifyDataSetChanged()
    }
}

class FavoritesTvSerieAdapter(
    private val context: Context,
    private val onClickListener: (FavoritesTvSeries) -> Unit
) : RecyclerView.Adapter<FavoritesTvSerieAdapter.ViewHolder>() {
    private var listFav = listOf<FavoritesTvSeries>()

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun Bind(
            movie: FavoritesTvSeries,
            context: Context,
            onClickListener: (FavoritesTvSeries) -> Unit
        ) {
            with(itemView) {
                Glide.with(context)
                    .load(ApiClient.IMAGE_BASE_URL + movie.poster_path)
                    .apply(requestOptions)
                    .into(imgmov_poster)
                txtmov_name.text = movie.name
                txtmov_rate.text = movie.vote_average
                itemView.setOnClickListener { onClickListener(movie) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_list, parent, false))


    override fun getItemCount(): Int = listFav.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.Bind(listFav[position], context, onClickListener)
    }

    fun setData(data: List<FavoritesTvSeries>) {
        listFav = data
        notifyDataSetChanged()
    }
}

