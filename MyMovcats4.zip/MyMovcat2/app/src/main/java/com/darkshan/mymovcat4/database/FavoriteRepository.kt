package com.darkshan.mymovcat4.database

import androidx.lifecycle.LiveData
import com.darkshan.mymovcat4.model.FavoriteMovie
import com.darkshan.mymovcat4.model.FavoritesTvSeries

class FavoriteRepository(private val favoriteDao: FavoriteDao) {

    fun saveMovie(favoriteMovie: FavoriteMovie) {
        favoriteDao.insertMovie(favoriteMovie)
    }

    fun loadFavMovieLiveData(): LiveData<List<FavoriteMovie>> {
        return favoriteDao.getAllMovies()
    }

    fun loadMovieById(id: String): List<FavoriteMovie> {
        return favoriteDao.getDetMovie(id)
    }

    fun loadTvSerieById(id: String): List<FavoritesTvSeries> {
        return favoriteDao.getDetTvSeries(id)
    }
    fun tvDeleteByName(name:String){
        return favoriteDao.deleteTvByName(name)
    }
    fun deleteTvByData(tvSeries: FavoritesTvSeries){
        return favoriteDao.deleteFavTv(tvSeries)
    }
    fun deleteFavmovie(id: String) {
        favoriteDao.deleteFavMovie(id)
    }

    fun saveTvSerie(favoritesTvSeries: FavoritesTvSeries) {
        favoriteDao.insertTvSeries(favoritesTvSeries)
    }

    fun loadFavTvSerieLiveData(): LiveData<List<FavoritesTvSeries>> {
        return favoriteDao.getAllTvSeries()
    }

    fun deleteFavTV(id: String) {
        favoriteDao.deleteFavMovie(id)
    }

}
