package com.darkshan.mymovcat4.api

import com.darkshan.mymovcat4.model.Movie
import com.darkshan.mymovcat4.model.TvSerie
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailServices(
    private val view: DetailView,
    private val apiService: ApiInterface
) {
    fun loadDetailMovies(id: String) {
        view.showLoading()
        apiService.getDetailMovie(id, ApiClient.API_KEY, getLocale())
            .enqueue(object : Callback<Movie> {
                override fun onFailure(call: Call<Movie>, t: Throwable) {
                    view.hideLoading()
                }

                override fun onResponse(call: Call<Movie>, response: Response<Movie>) {
                    if (response.isSuccessful) {
                        val data = response.body()!!
                        view.loadDetailMovie(data)
                    }
                    view.hideLoading()
                }
            })

    }

    fun loadDetailTvSeries(id: String) {
        view.showLoading()
        apiService.getDetailTv(id, ApiClient.API_KEY, getLocale())
            .enqueue(object : Callback<TvSerie> {
                override fun onFailure(call: Call<TvSerie>, t: Throwable) {
                    view.hideLoading()
                }

                override fun onResponse(call: Call<TvSerie>, response: Response<TvSerie>) {
                    if (response.isSuccessful) {
                        val data = response.body()!!
                        view.loadDetailTvSeries(data)
                    }
                    view.hideLoading()
                }
            })
    }


}

interface DetailView {
    fun showLoading()
    fun hideLoading()
    fun loadDetailMovie(data: Movie)
    fun loadDetailTvSeries(data: TvSerie)
}