package com.darkshan.mymovcat4.api

import android.view.View
import java.util.*

fun View.visible() {
    visibility = View.VISIBLE
}

fun View.invisible() {
    visibility = View.INVISIBLE
}

fun getLocale(): String {
    val locale = Locale.getDefault().language
    var language = "language"
    if (locale == "en") {
        language = "en-US"
    } else if (locale == "in") {
        language = "id-IN"
    }
    return language
}