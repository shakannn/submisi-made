package com.darkshan.mymovcat4.api

import com.darkshan.mymovcat4.model.TvSeries
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TvSeriesService(
    private val view: TvSeriesView,
    private val apiService: ApiInterface
) {
    fun loadTvSeries() {
        view.showTvLoading()
        apiService.getTv(ApiClient.API_KEY, getLocale()).enqueue(object : Callback<TvSeries> {
            override fun onFailure(call: Call<TvSeries>, t: Throwable) {
                view.hideTvLoading()
            }

            override fun onResponse(call: Call<TvSeries>, response: Response<TvSeries>) {
                if (response.isSuccessful) {
                    val data = response.body()!!
                    view.loadListTvSeries(data)
                }
                view.hideTvLoading()
            }
        })
    }


}

interface TvSeriesView {
    fun showTvLoading()
    fun hideTvLoading()
    fun loadListTvSeries(data: TvSeries)
}