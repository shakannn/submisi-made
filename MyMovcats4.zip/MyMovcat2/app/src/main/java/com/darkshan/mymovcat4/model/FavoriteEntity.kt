package com.darkshan.mymovcat4.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.darkshan.mymovcat4.activity.MainActivity
import kotlinx.android.parcel.Parcelize

@Entity(tableName = MainActivity.TBL_Movie_NAME)
@Parcelize
data class FavoriteMovie(
    @PrimaryKey(autoGenerate = false) @ColumnInfo(name = "id") var id: String,
    @ColumnInfo(name = "title") var title: String,
    @ColumnInfo(name = "vote_average") var vote_average: String,
    @ColumnInfo(name = "poster_path") var poster_path: String
) : Parcelable

@Entity(tableName = MainActivity.TBL_Tv_NAME)
@Parcelize
data class FavoritesTvSeries(
    @PrimaryKey(autoGenerate = false) @ColumnInfo(name = "id") var id: String,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "vote_average") var vote_average: String,
    @ColumnInfo(name = "poster_path") var poster_path: String
) : Parcelable