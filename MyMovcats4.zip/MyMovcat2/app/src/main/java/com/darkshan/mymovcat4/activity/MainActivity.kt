package com.darkshan.mymovcat4.activity

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.darkshan.mymovcat4.R
import com.darkshan.mymovcat4.adapter.PagerAdapter
import com.darkshan.mymovcat4.api.*
import com.darkshan.mymovcat4.model.Movies
import com.darkshan.mymovcat4.model.TvSeries
import com.darkshan.mymovcat4.ui.main.FavoriteMovieFragment
import com.darkshan.mymovcat4.ui.main.FavoriteTvSeriesFragment
import com.darkshan.mymovcat4.ui.main.MovieFragment
import com.darkshan.mymovcat4.ui.main.TvSeriesFragment
import com.darkshan.mymovcat4.viewmodel.FavoriteMovieViewModel
import com.darkshan.mymovcat4.viewmodel.MovieViewModel
import com.darkshan.mymovcat4.viewmodel.TvSeriesViewModel
import kotlinx.android.synthetic.main.main_activity.*

class MainActivity : AppCompatActivity(), MovieView, TvSeriesView {

    private lateinit var movieViewModel: MovieViewModel
    private lateinit var tvviewModel: TvSeriesViewModel
    private lateinit var movieservice: MoviesService
    private lateinit var tvSeriesService: TvSeriesService
    private lateinit var favoriteMovieViewModel: FavoriteMovieViewModel

    companion object {
        const val MOVIE = "MOVIE"
        const val TV_SERIES = "TV_SERIES"
        const val TYPE = "type"
        const val DATABASE_DI = "database.di"
        const val DATA_EXTRA_TV = "data"
        const val DATA_EXTRA_MOVIE = "data"
        const val TBL_Movie_NAME = "favoritesMovies"
        const val TBL_Tv_NAME = "favoritesTvSeries"
        const val DBNAME = "favDb"
        const val CONTEXTAPP = "context.app.di"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        val pagerAdapter = PagerAdapter(this, supportFragmentManager)
        pagerAdapter.addTabs(MovieFragment(), resources.getString(R.string.tab_one))
        pagerAdapter.addTabs(TvSeriesFragment(), resources.getString((R.string.tab_two)))
        pagerAdapter.addTabs(FavoriteMovieFragment(), resources.getString(R.string.tab_three))
        pagerAdapter.addTabs(FavoriteTvSeriesFragment(), resources.getString(R.string.tab_four))
        vpager.adapter = pagerAdapter
        tabs.setupWithViewPager(vpager)
        setSupportActionBar(appbar)

        val apiService = ApiClient.getRetrofitInst()
        movieservice = MoviesService(this, apiService)
        tvSeriesService = TvSeriesService(this, apiService)

        movieViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[MovieViewModel::class.java]

        tvviewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[TvSeriesViewModel::class.java]
        //favoriteMovieViewModel=ViewModelProvider(this,ViewModelProvider.NewInstanceFactory())[FavoriteMovieViewModel::class.java]
//        favoriteMovieViewModel = ViewModelProvider(
//            this,
//            ViewModelProvider.NewInstanceFactory()
//        )[FavoriteMovieViewModel::class.java]
//
//        favoriteMovieViewModel = ViewModelProvider(
//            this,
//            ViewModelProvider.NewInstanceFactory()
//        )[FavoriteMovieViewModel::class.java]


        if (tvviewModel.getTvSeries().value == null) {
            tvSeriesService.loadTvSeries()
        }
        if (movieViewModel.getMovies().value == null) {
            movieservice.loadMovies()
        }

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_change_settings) {
            val sIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
            startActivity(sIntent)
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun showLoading() {

    }

    override fun hideLoading() {

    }

    override fun loadListMovie(data: Movies) {
        movieViewModel.setMovies(data)
    }

    override fun showTvLoading() {

    }

    override fun hideTvLoading() {

    }

    override fun loadListTvSeries(data: TvSeries) {
        tvviewModel.setTvSeries(data)
    }
}
