package com.darkshan.mymovcat4.api

import com.darkshan.mymovcat4.model.Movies
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MoviesService(
    private val view: MovieView,
    private val apiService: ApiInterface
) {
    fun loadMovies() {
        view.showLoading()
        apiService.getMovie(ApiClient.API_KEY, getLocale()).enqueue(object : Callback<Movies> {
            override fun onFailure(call: Call<Movies>, t: Throwable) {
                view.hideLoading()
            }

            override fun onResponse(call: Call<Movies>, response: Response<Movies>) {
                if (response.isSuccessful) {
                    val data = response.body()!!
                    view.loadListMovie(data)
                }
                view.hideLoading()
            }
        })
    }


}

interface MovieView {
    fun showLoading()
    fun hideLoading()
    fun loadListMovie(data: Movies)
}